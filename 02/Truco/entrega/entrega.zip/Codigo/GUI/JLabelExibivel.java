package GUI;

import javax.swing.JLabel;
import truco.Exibivel;

public class JLabelExibivel extends JLabel implements Exibivel{
    
}
