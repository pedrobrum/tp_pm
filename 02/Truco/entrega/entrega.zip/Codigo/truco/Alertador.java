package truco;

public interface Alertador {
    public void showMessage(String message);
}
