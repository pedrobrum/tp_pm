package truco;

public interface Exibivel{
    public void setText(String s);
}
